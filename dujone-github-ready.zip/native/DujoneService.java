package com.dujone.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;

public class DujoneService extends Service {
    public static final String ACTION_STOP = "com.dujone.app.STOP";
    static final String CHANNEL = "dujone_run";
    static final int NOTI_ID = 4101;

    private PowerManager.WakeLock wl;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback cb;
    private boolean online = false;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "দুজনে — চালু আছে",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            shutdownAll();
            return START_NOT_STICKY;
        }

        online = isOnlineNow();
        try {
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTI_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(NOTI_ID, n);
            }
        } catch (Throwable t) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (wl == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dujone:run");
            wl.setReferenceCounted(false);
            wl.acquire();
        }
        registerNetwork();
        return START_STICKY;
    }

    private void registerNetwork() {
        if (cb != null) return;
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        cb = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) { setOnline(true); }
            @Override public void onLost(Network network) { setOnline(isOnlineNow()); }
            @Override public void onCapabilitiesChanged(Network n, NetworkCapabilities c) {
                setOnline(c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET));
            }
        };
        try { cm.registerDefaultNetworkCallback(cb); } catch (Throwable ignored) { }
    }

    private boolean isOnlineNow() {
        try {
            ConnectivityManager c = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = c.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities caps = c.getNetworkCapabilities(n);
            return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Throwable t) { return false; }
    }

    private synchronized void setOnline(boolean now) {
        boolean was = online;
        online = now;
        if (was != now) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.notify(NOTI_ID, buildNotification());
        }
        if (now) MainActivity.nudgeOnline();   // নেট আসা মাত্র পেজকে জানাও → ATAS 1 আবার শুরু
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pOpen = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, DujoneService.class).setAction(ACTION_STOP);
        PendingIntent pStop = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("দুজনে চালু আছে")
                .setContentText(online ? "ইন্টারনেট আছে — ব্যাকগ্রাউন্ডে চলছে"
                                       : "ইন্টারনেটের অপেক্ষায় — সংযোগ এলেই চালু হবে")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(pOpen)
                .addAction(0, "সম্পূর্ণ বন্ধ করুন", pStop)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .build();
    }

    private void shutdownAll() {
        stopForeground(true);
        stopSelf();
        android.os.Process.killProcess(android.os.Process.myPid()); // মাইক সহ সব বন্ধ
    }

    @Override
    public void onDestroy() {
        try { if (cm != null && cb != null) cm.unregisterNetworkCallback(cb); } catch (Throwable ignored) { }
        cb = null;
        if (wl != null && wl.isHeld()) wl.release();
        super.onDestroy();
    }
}
