package com.dujone.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;

/**
 * Android 14+ ফোন চালুর সময় মাইক-সার্ভিস নিজে চালু করতে দেয় না।
 * তাই রিস্টার্টের পর একটি নোটিফিকেশন দেখায় — ১ ট্যাপেই অ্যাপ + সার্ভিস চালু।
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(a) && !"android.intent.action.QUICKBOOT_POWERON".equals(a)) return;

        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel("dujone_boot", "দুজনে — রিস্টার্টের পর",
                    NotificationManager.IMPORTANCE_HIGH));
        }
        Intent open = new Intent(ctx, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent p = PendingIntent.getActivity(ctx, 2, open, PendingIntent.FLAG_IMMUTABLE);
        try {
            nm.notify(4102, new NotificationCompat.Builder(ctx, "dujone_boot")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("দুজনে")
                    .setContentText("ফোন চালু হয়েছে — চালু করতে ট্যাপ করুন")
                    .setAutoCancel(true)
                    .setContentIntent(p)
                    .build());
        } catch (Throwable ignored) { }
    }
}
