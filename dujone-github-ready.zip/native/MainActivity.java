package com.dujone.app;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.media.AudioManager;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.BridgeActivity;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class MainActivity extends BridgeActivity {
    private static final int REQ_PERMS = 7701;
    private static WeakReference<MainActivity> LIVE = new WeakReference<>(null);
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean inBackground = false;

    // ব্যাকগ্রাউন্ডে থাকলে প্রতি ৪ সেকেন্ডে WebView-কে "চালু" অবস্থায় ধরে রাখে
    private final Runnable keeper = new Runnable() {
        @Override public void run() {
            keepWebViewAlive();
            if (inBackground) h.postDelayed(this, 4000);
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LIVE = new WeakReference<>(this);

        // Back চাপলে অ্যাপ বন্ধ না হয়ে ব্যাকগ্রাউন্ডে চলে যাবে
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { moveTaskToBack(true); }
        });

        setupWebView();
        askPermissions();
    }

    /** ফোনের সিস্টেম ফন্ট/ডিসপ্লে সাইজ যেন অ্যাপের লেআউট না ভাঙে + অডিও অটোপ্লে + স্পিকার ব্রিজ */
    private void setupWebView() {
        try {
            WebView w = getBridge().getWebView();
            WebSettings ws = w.getSettings();
            ws.setTextZoom(100);
            ws.setMediaPlaybackRequiresUserGesture(false);
            w.addJavascriptInterface(new Object() {
                @JavascriptInterface
                public void speaker(final boolean on) {
                    try {
                        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                        if (am == null) return;
                        if (on) {
                            am.setMode(AudioManager.MODE_IN_COMMUNICATION);
                            am.setSpeakerphoneOn(true);
                        } else {
                            am.setSpeakerphoneOn(false);
                            am.setMode(AudioManager.MODE_NORMAL);
                        }
                    } catch (Throwable ignored) { }
                }
            }, "DujoneNative");
        } catch (Throwable ignored) { }
    }

    @Override
    public void onResume() {
        super.onResume();
        inBackground = false;
        h.removeCallbacks(keeper);
        setJsBackgroundFlag(false);
        startRunnerIfReady();
    }

    @Override
    public void onPause() {
        super.onPause();
        inBackground = true;
        setJsBackgroundFlag(true);
        keepWebViewAlive();
        h.removeCallbacks(keeper);
        h.postDelayed(keeper, 1000);
    }

    /**
     * অডিও/মাইক সচল রাখতে keepWebViewAlive() WebView-কে "visible" বলে জিইয়ে রাখে,
     * তাই document.hidden দিয়ে ব্যাকগ্রাউন্ড বোঝা যায় না। তাই আলাদা করে JS-কে সত্যিকারের
     * Activity lifecycle জানিয়ে দেওয়া হয়, যা notify() ব্যাকগ্রাউন্ডে মেসেজ-নোটিফিকেশন
     * পাঠানোর জন্য ব্যবহার করে।
     */
    private void setJsBackgroundFlag(boolean bg) {
        try {
            getBridge().eval("window.__djBg=" + bg + ";", null);
        } catch (Throwable ignored) { }
    }

    @Override
    public void onStop() {
        super.onStop();
        keepWebViewAlive();
    }

    private void keepWebViewAlive() {
        try {
            WebView w = getBridge().getWebView();
            w.onResume();
            w.resumeTimers();
            w.dispatchWindowVisibilityChanged(View.VISIBLE);
        } catch (Throwable ignored) { }
    }

    /** সার্ভিস থেকে ডাকা হয়: ইন্টারনেট ফিরলে পেজকে জানায়। */
    public static void nudgeOnline() {
        final MainActivity a = LIVE.get();
        if (a == null) return;
        a.runOnUiThread(() -> {
            a.keepWebViewAlive();
            try {
                a.getBridge().eval("window.dispatchEvent(new Event('online'))", null);
            } catch (Throwable ignored) { }
        });
    }

    private boolean micGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void askPermissions() {
        ArrayList<String> need = new ArrayList<>();
        if (!micGranted()) need.add(Manifest.permission.RECORD_AUDIO);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.CAMERA);
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) {
            ActivityCompat.requestPermissions(this, need.toArray(new String[0]), REQ_PERMS);
        } else {
            startRunnerIfReady();
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] perms, @NonNull int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_PERMS) startRunnerIfReady();
    }

    /** অ্যাপ সামনে থাকা অবস্থায় (এটাই জরুরি) ফোরগ্রাউন্ড সার্ভিস চালু করে। */
    private void startRunnerIfReady() {
        if (!micGranted()) return;
        try {
            ContextCompat.startForegroundService(this, new Intent(this, DujoneService.class));
        } catch (Throwable ignored) { }
        askBatteryExemptionOnce();
    }

    private void askBatteryExemptionOnce() {
        SharedPreferences p = getSharedPreferences("dj", Context.MODE_PRIVATE);
        if (p.getBoolean("battAsked", false)) return;
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                p.edit().putBoolean("battAsked", true).apply();
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        } catch (Throwable ignored) { }
    }
}
