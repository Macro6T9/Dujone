// ব্যবহার:  npm install  →  node setup.js
const fs = require('fs'), path = require('path'), { execSync } = require('child_process');
const run = c => execSync(c, { stdio: 'inherit' });
const htmlOnly = process.argv.includes('--html-only');

// ---------- ১) HTML প্যাচ ----------
function patchHtml() {
  let h = fs.readFileSync('src/index.original.html', 'utf8');
  const rep = (from, to, label) => {
    const before = h;
    h = typeof from === 'string' ? h.split(from).join(to) : h.replace(from, to);
    console.log((before !== h ? '✔ ' : '✘ (মেলেনি) ') + label);
  };
  // অফলাইনে প্রথমবার খুললেও যেন ফাঁকা না আসে: CDN বাদ, লোকাল ফাইল
  rep(/<link href="https:\/\/fonts\.googleapis\.com[^>]*>\n?/, '', 'Google Fonts লিংক বাদ (সিস্টেম বাংলা ফন্ট চলবে)');
  rep('https://cdn.jsdelivr.net/npm/peerjs@1.5.4/dist/peerjs.min.js', 'peerjs.min.js', 'PeerJS লোকাল ফাইল');
  // QR স্ক্যানের জন্য jsQR (Android WebView-তে BarcodeDetector নেই)
  rep('<script src="peerjs.min.js"></script>', '<script src="peerjs.min.js"></script>\n<script src="jsQR.js"></script>', 'jsQR স্ক্রিপ্ট ট্যাগ যোগ');
  // ATAS 1 ডিফল্টে চালু (আগে সেভ করা সেটিং থাকলে সেটাই চলবে)
  rep('auto:true,toggle:false,', 'auto:true,always:true,listen:true,toggle:false,', 'ATAS 1 ও ATAS 2 ডিফল্ট চালু');

  // ATAS-এর পাশের বাংলা ব্র্যাকেট বিবরণ বাদ — শুধু "ATAS" লেখাই থাকবে
  rep('ATAS (অলটাইম অডিও)', 'ATAS', 'ATAS পাশের ব্র্যাকেট লেখা বাদ');
  // রুম কোড অ্যাপ বন্ধ/চালুর পরেও মনে রাখুক (sessionStorage → localStorage) — ম্যানুয়াল লগ-আউট ছাড়া মুছবে না
  rep(/sessionStorage/g, 'localStorage', 'রুম কোড স্থায়ীভাবে সংরক্ষণ (ম্যানুয়াল লগ-আউট না করা পর্যন্ত)');

  // সেটিংসে "লগ-আউট" বাটন যোগ (রুম থেকে বের হওয়ার একমাত্র পথ, রুম-শিট ছাড়াও)
  rep(
    '<div class="row"><span>সব সেটিংস রিসেট</span>',
    '<div class="row"><span>লগ-আউট (রুম থেকে বের হন)</span><span><button class="chip" id="rmLeaveSettings">লগ-আউট</button></span></div>\n          <div class="row"><span>সব সেটিংস রিসেট</span>',
    'সেটিংসে লগ-আউট বাটন যোগ'
  );
  rep(
    "$('#rmLeave').onclick=()=>{closeRoom();S.msgs=[];S.clips=[];renderMsgs();renderClips();refresh();showGate('home');toast('রুম থেকে বের হয়েছেন')};",
    "const doLogout=()=>{closeRoom();S.msgs=[];S.clips=[];renderMsgs();renderClips();refresh();showGate('home');toast('লগ-আউট হয়েছে')};\n$('#rmLeave').onclick=doLogout;$('#rmLeaveSettings').onclick=()=>{if(confirm(TT('লগ-আউট করবেন? আবার শুধু রুম কোড দিয়ে যুক্ত হতে হবে।')))doLogout()};",
    'সেটিংস লগ-আউট বাটন ওয়্যারিং'
  );

  // app সত্যিকারের ব্যাকগ্রাউন্ডে আছে কিনা — নেটিভ কোড থেকে সেট হয়; document.hidden-এর
  // উপর নির্ভর করা যাচ্নি না, কারণ অডিও/মাইক সচল রাখতে নেটিভ অংশ WebView-কে "visible"
  // হিসেবে জিইয়ে রাখে (নিচে দেখুন), যা document.hidden-কে false করে রাখতে পারে।
  rep(
    "let LANG=(()=>{try{return localStorage.getItem('dj-lang')==='en'?'en':'bn'}catch(e){return'bn'}})();",
    "let LANG=(()=>{try{return localStorage.getItem('dj-lang')==='en'?'en':'bn'}catch(e){return'bn'}})();\nwindow.__djBg=false;",
    'ব্যাকগ্রাউন্ড-স্টেট ফ্ল্যাগ যোগ'
  );

  // মেসেজ এলে আসল Android নোটিফিকেশন (Capacitor LocalNotifications থাকলে তা দিয়ে, নইলে ওয়েব Notification API দিয়ে)
  rep(
    "function notify(t,b){if(!S.set.notif||!document.hidden||!('Notification' in window)||Notification.permission!=='granted')return;try{new Notification(t,{body:b,tag:'dujon'})}catch(e){}}",
    `function notify(t,b){
  if(!S.set.notif||!(document.hidden||window.__djBg))return;
  try{
    const C=window.Capacitor;
    if(C&&C.Plugins&&C.Plugins.LocalNotifications){
      C.Plugins.LocalNotifications.schedule({notifications:[{title:t,body:b,id:Math.floor(Date.now()%2000000000),channelId:'dujone_msg'}]});
      return;
    }
  }catch(e){}
  if(!('Notification' in window)||Notification.permission!=='granted')return;
  try{new Notification(t,{body:b,tag:'dujon'})}catch(e){}
}`,
    'মেসেজ নোটিফিকেশন (Android LocalNotifications, __djBg মিলিয়ে)'
  );
  rep(
    "function askNotif(){if(!('Notification' in window)||Notification.permission!=='default')return;",
    `function askNotif(){
  try{
    const C=window.Capacitor;
    if(C&&C.Plugins&&C.Plugins.LocalNotifications){
      C.Plugins.LocalNotifications.createChannel&&C.Plugins.LocalNotifications.createChannel({id:'dujone_msg',name:'মেসেজ ও কল',importance:4,vibration:true});
      C.Plugins.LocalNotifications.requestPermissions().then(p=>{if(p&&p.display==='granted'){S.set.notif=true;try{saveSet();syncSet()}catch(e){}}});
      return;
    }
  }catch(e){}
  if(!('Notification' in window)||Notification.permission!=='default')return;`,
    'নোটিফিকেশন পারমিশন (Android)'
  );
  // সেটিংসে "নোটিফিকেশন" টগল চাপলে (notifApply): WebView-তে window.Notification আসলে
  // নেই বলেই আগের কোড টগল অন করার সাথে সাথে নিজে থেকে বন্ধ করে দিত — এটা আসল বাগ ছিল।
  rep(
    "function notifApply(){\n  if(!S.set.notif)return;\n  if(!('Notification' in window)){S.set.notif=false;saveSet();syncSet();return toast('এই ব্রাউজারে সমর্থিত নয়')}\n  Notification.requestPermission().then(p=>{if(p!=='granted'){S.set.notif=false;saveSet();syncSet();toast('নোটিফিকেশনের অনুমতি পাওয়া যায়নি')}});\n}",
    `function notifApply(){
  if(!S.set.notif)return;
  try{
    const C=window.Capacitor;
    if(C&&C.Plugins&&C.Plugins.LocalNotifications){
      C.Plugins.LocalNotifications.createChannel&&C.Plugins.LocalNotifications.createChannel({id:'dujone_msg',name:'মেসেজ ও কল',importance:4,vibration:true});
      C.Plugins.LocalNotifications.requestPermissions().then(p=>{if(!p||p.display!=='granted'){S.set.notif=false;saveSet();syncSet();toast('নোটিফিকেশনের অনুমতি পাওয়া যায়নি')}});
      return;
    }
  }catch(e){}
  if(!('Notification' in window)){S.set.notif=false;saveSet();syncSet();return toast('এই ব্রাউজারে সমর্থিত নয়')}
  Notification.requestPermission().then(p=>{if(p!=='granted'){S.set.notif=false;saveSet();syncSet();toast('নোটিফিকেশনের অনুমতি পাওয়া যায়নি')}});
}`,
    'সেটিংস নোটিফিকেশন-টগল ফিক্স (Android-এ নিজে বন্ধ হয়ে যাওয়ার বাগ)'
  );

  fs.mkdirSync('www', { recursive: true });
  fs.writeFileSync('www/index.html', h);
  const pj = 'node_modules/peerjs/dist/peerjs.min.js';
  if (fs.existsSync(pj)) { fs.copyFileSync(pj, 'www/peerjs.min.js'); console.log('✔ peerjs.min.js কপি হয়েছে'); }
  else console.log('✘ peerjs পাওয়া যায়নি — আগে `npm install` চালান');
  const jq = 'node_modules/jsqr/dist/jsQR.js';
  if (fs.existsSync(jq)) { fs.copyFileSync(jq, 'www/jsQR.js'); console.log('✔ jsQR.js কপি হয়েছে'); }
  else console.log('✘ jsqr পাওয়া যায়নি — আগে `npm install` চালান');
}
patchHtml();
if (htmlOnly) process.exit(0);

// ---------- ২) Android প্রজেক্ট ----------
if (!fs.existsSync('android')) run('npx cap add android');

const javaDir = 'android/app/src/main/java/com/dujone/app';
fs.mkdirSync(javaDir, { recursive: true });
for (const f of fs.readdirSync('native')) fs.copyFileSync(path.join('native', f), path.join(javaDir, f));
console.log('✔ Java ফাইল বসানো হয়েছে');

// ---------- ৩) Manifest প্যাচ ----------
const mp = 'android/app/src/main/AndroidManifest.xml';
let m = fs.readFileSync(mp, 'utf8');
if (!m.includes('DujoneService')) {
  const perms = ['ACCESS_NETWORK_STATE', 'CAMERA', 'RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS', 'FOREGROUND_SERVICE',
    'FOREGROUND_SERVICE_MICROPHONE', 'POST_NOTIFICATIONS', 'RECEIVE_BOOT_COMPLETED', 'WAKE_LOCK',
    'REQUEST_IGNORE_BATTERY_OPTIMIZATIONS', 'VIBRATE']
    .map(p => `    <uses-permission android:name="android.permission.${p}" />`).join('\n');
  const comps = `
        <service android:name=".DujoneService" android:exported="false" android:foregroundServiceType="microphone" />
        <receiver android:name=".BootReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
            </intent-filter>
        </receiver>
    </application>`;
  const feats = `    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />`;
  m = m.replace('</application>', comps).replace('</manifest>', perms + '\n' + feats + '\n</manifest>');
  fs.writeFileSync(mp, m);
  console.log('✔ Manifest প্যাচ হয়েছে');
} else console.log('• Manifest আগেই প্যাচ করা');

// ---------- ৪) অ্যাপ আইকন (লোগো) ----------
const res = 'android/app/src/main/res';
for (const d of fs.readdirSync('resources')) {
  const src = path.join('resources', d);
  if (!fs.statSync(src).isDirectory()) continue;
  fs.mkdirSync(path.join(res, d), { recursive: true });
  for (const f of fs.readdirSync(src)) fs.copyFileSync(path.join(src, f), path.join(res, d, f));
}
fs.mkdirSync(path.join(res, 'mipmap-anydpi-v26'), { recursive: true });
fs.mkdirSync(path.join(res, 'values'), { recursive: true });
const adaptive = '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n';
fs.writeFileSync(path.join(res, 'mipmap-anydpi-v26/ic_launcher.xml'), adaptive);
fs.writeFileSync(path.join(res, 'mipmap-anydpi-v26/ic_launcher_round.xml'), adaptive);
fs.writeFileSync(path.join(res, 'values/ic_launcher_background.xml'), '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0A0813</color>\n</resources>\n');
for (const f of ['drawable-v24/ic_launcher_foreground.xml', 'drawable/ic_launcher_background.xml']) {
  const fp = path.join(res, f); if (fs.existsSync(fp)) fs.unlinkSync(fp);
}
console.log('✔ অ্যাপ আইকন বসানো হয়েছে');

run('npx cap sync android');
console.log('\nশেষ। এবার:  npx cap open android   (Android Studio-তে Build > Build APK)');
